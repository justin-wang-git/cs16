#ifndef STRFUNCS_H
#define STRFUNCS_H
#include <string>

using namespace std;


bool isPalindrome(const string s1);


#endif //STRFUNCS_H