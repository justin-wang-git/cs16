#include "strFuncs.h"
#include <cctype>
#include <string>
#include <algorithm>

using namespace std;


/* Precondition: s1 is a valid string that may contain upper or lower case alphabets, no spaces or special characters
 * Postcondition: Returns true if s1 is a palindrome, false otherwise
 *
 * Palindromes are NOT case-sensitive - "RaCecaR" is a valid palindrome
 *
 *You should provide a recursive solution*/
bool isPalindrome(const string s1)
{
    string s1new = s1;
    int lastIndex = s1new.length() - 1;
    if (s1new.length() <= 1)
    {
        return true;
    }
    if (tolower(s1new[0]) == tolower(s1new[lastIndex]))
    {
        s1new = s1new.substr(1, lastIndex - 1);
        return isPalindrome(s1new);
    }
}

