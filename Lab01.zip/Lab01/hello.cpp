#include <iostream>

using namespace std;


int main() {
	//printing code
	cout << "Hello, world!" << endl;
	cout << "I am ready for CS16!" << endl;
	return 0;
}