//block.cpp
/*
 Justin Wang    6949184
 Isiah Fimbrez  7199532
 */
#include <iostream>
#include <string>
using namespace std;

int main()
{
	int row = 1;
	int column = 1;

	while(row > 0 && column > 0)
	{
		cout << "Enter number of rows and columns: \n";
        cin >> row;
        cin >> column;
        int k = 0;
		while(k < row)
		{
            int j = 0;
			while(j < column)
			{
				cout << "X.";
                ++j;
			}
			cout << endl;
            ++k;
		}
	}
	return 0;
}
