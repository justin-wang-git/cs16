#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
/*
Justin Wang 6949184
Isiah Fimbrez 7199532
01/09/20
*/
using namespace std;

int main()
{
    int number = 0;
    float sum = 0;
    cout << setprecision(3);
    cout << fixed;
    cout << "Enter the value of the parameter 'n' in the Leibniz formula (or -1 to quit): " << endl;
    cin >> number;
    while (number != -1)
    {
            for (int x = 0; x <= number; x++)
            {
                sum = sum + pow(-1, x) / (2 * x + 1);
            }            
           sum = sum * 4;
        if (number == 0)
           {
               cout << "The approximate value of pi using " << number + 1 << " term is: " << sum << endl;
           } 
        else
        {
            cout << "The approximate value of pi using " << number + 1 << " terms is: " << sum << endl;
        }
        sum = 0;
        cout << "Enter the value of the parameter 'n' in the Leibniz formula (or -1 to quit): " << endl;
        cin >> number;   
    }
    return 0;
}