// utility.cpp

// IN THIS FILE, define any of your OWN functions you may need to 
// solve the problems.    
#include <cmath>

// You will need to include the function prototype in "utility.h" and
// then be sure to  #include "utility.h" in the file where you use
// these functions

bool approxEqual (double d1, double d2, double tolerance)
{
    return fabs(d1 - d2) < tolerance;
}