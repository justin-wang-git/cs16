// myProg02.cpp 
// Author: Justin Wang 6949184
// Author: Isiah Fimbrez 7199532

#include <iostream> // for printf()
#include <cstdlib> // for exit(), perror()
#include <fstream> // for ifstream 

using namespace std;

void countStuff(string inputFile, int &numberOfDucks, int &numberOfAnimals, int &numberOfNoDucks)
{
  string animalFiles;
  ifstream in;
  in.open(inputFile);
  while (in)
  {
    getline(in, animalFiles);
    if(in)
    {
      if (animalFiles == "duck")
      {
        numberOfDucks++;
      }
      else
      {
        numberOfNoDucks++;
      }
      numberOfAnimals++;
    }
  }
  in.close();
}


int main(int argc, char *argv[])
{
  if (argc!=2) {
    // if argc is not 2, print an error message and exit
    cerr << "Usage: "<< argv[0] << " inputFile" << endl;
    exit(1); // defined in cstdlib
  }
  int noD = 0;
  int noA = 0;
  int noND = 0;

  countStuff(argv[1], noD, noA, noND);
  cout << "Report for " << argv[1] << ":" << endl;
  cout << "   Animal count:    " << noA << endl;
  cout << "   Duck count:      " << noD << endl;
  cout << "   Non duck count:  " << noND << endl;

  return 0;
}
