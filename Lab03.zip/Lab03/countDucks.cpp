// countDucks.cpp 
// Author: Justin Wang 6949184
// Author: Isiah Fimbrez 7199532

#include <iostream> // for printf()
#include <cstdlib> // for exit(), perror()
#include <fstream> // for ifstream

using namespace std;

int countDucks(string inputFile)
{
  int numberOfDucks = 0;
  string animalFiles;
  ifstream in;
  in.open(inputFile);
  while (in)
  {
    getline(in, animalFiles);
    if (animalFiles == "duck")
    {
      numberOfDucks++;
    }
  }
  return numberOfDucks;
}

int main(int argc, char *argv[])
{
  if (argc!=2) {
    // if argc is not 2, print an error message and exit
    cerr << "Usage: "<< argv[0] << " inputFile" << endl;
    exit(1); // defined in cstdlib
  }

  cout << "There were " << countDucks(argv[1]) << " ducks in " << argv[1] << endl;

  return 0;
}
