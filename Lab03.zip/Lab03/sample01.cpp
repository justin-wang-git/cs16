// sample01.cpp
#include <iostream>
using namespace std;
 
int main() {
    // Simple for loop that counts from 1 up to n
 
    int n=5;
 
    for (int i=1; i<=n; i++) {
       cout << "i=" << i << endl;
    }
 
    return 0;
}

