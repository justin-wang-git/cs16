// myProg01.cpp
// Author: Justin Wang 6949184
// Author: Isiah Fimbrez 7199532

#include <iostream>
using namespace std;
 
int main() 
{
    // Simple for loop that counts down from n to 1
 
    int n = 5;
 
    for (int i = n; i > 0; i--) 
    {
       cout << i << " ";
    }
    cout << "\n";
    return 0;
}

